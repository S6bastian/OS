#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <errno.h>
#include <sys/shm.h>

#define KEY 0x1111
#define SHMSZ     27

union semun
{
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};



struct sembuf p = {0, -1, SEM_UNDO};
struct sembuf v = {0, +1, SEM_UNDO};

int main()
{
    int shmid,shmid2,shmid3,times = 3;
    key_t key,key2,key3;
    char *shm,*shm2,*shm3;
    /*
        shm hace de lock entre m y M
        shm2 almacena lo que se va a imprimir
        shm3 almacena la posición en la que se guardarán los datos de shm2
    */

    key = 1111; key2 = 7777; key3 = 3333;

    if ((shmid = shmget(key, SHMSZ, IPC_CREAT | 0666)) < 0) {
        perror("shmget");
        exit(1);
    }

    if ((shmid2 = shmget(key2, SHMSZ, IPC_CREAT | 0666)) < 0) {
        perror("shmget");
        exit(1);
    }

    if ((shmid3 = shmget(key3, SHMSZ, IPC_CREAT | 0666)) < 0) {
        perror("shmget");
        exit(1);
    }

    if ((shm = shmat(shmid, NULL, 0)) == (char *) -1) {
        perror("shmat");
        exit(1);
    }

    if ((shm2 = shmat(shmid2, NULL, 0)) == (char *) -1) {
        perror("shmat");
        exit(1);
    }

    if ((shm3 = shmat(shmid3, NULL, 0)) == (char *) -1) {
        perror("shmat");
        exit(1);
    }

    *shm = 'm';
    sprintf(shm3,"0\0");

    int id = semget(KEY, 1, 0666 | IPC_CREAT);
    if (id < 0)
    {
        perror("semget");
        exit(11);
    }
    union semun u;
    u.val = 1;
    if (semctl(id, 0, SETVAL, u) < 0)
    {
        perror("semctl");
        exit(12);
    }
    

    char *s = "abcdefgh";
    int l = strlen(s);
    for (int i = 0; i < l; ++i)
    {
        if (semop(id, &p, 1) < 0)
        {
            perror("semop p");
            exit(13);
        }
        if (*shm=='m'){
            int pos=atoi(shm3);
            for (int j = 0; j < times; j++) {
                shm2[pos++]=s[i];
            }
            sprintf(shm3,"%d\0",pos);
            *shm='M';
        }
        else {
            i--;
        }
        
        if (semop(id, &v, 1) < 0)
        {
            perror("semop p");
            exit(14);
        }
    }
}